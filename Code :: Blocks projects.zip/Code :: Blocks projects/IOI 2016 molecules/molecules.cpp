
#include "molecules.h"
#include <bits/stdc++.h>
#define ll long long
using namespace std;
const ll inf = 2e5+9;
ll n,pre[inf];
pair<ll,ll> a[inf];

vector<int> find_subset(int l, int r, vector<int> w) {
    vector<int> ans;
    n = w.size();
    for(ll i=1;i<=n;i++)
        a[i] = make_pair(w[i-1],i-1);

    sort(a+1,a+1+n);
    for(ll i=1;i<=n;i++)
        pre[i] = pre[i-1]+a[i].first;

    set<pair<ll,ll> > s;

    for(ll i=1;i<=n;i++){

        s.insert(make_pair(pre[i-1],i));
        set< pair<ll,ll> > ::iterator it = s.lower_bound( make_pair( pre[i]-r , 0 ) );

        if( it == s.end() || it->first > pre[i] - l )
            continue;

        for(ll j = it->second ; j <= i ;j++)
            ans.push_back(a[j].second);

        return ans;

        /*for(ll j=i;j<=n;j++){
            if(pre[j] - pre[i-1] >=l && pre[j] - pre[i-1] <= r){
                for(ll z=i;z<=j;z++)
                    ans.push_back(a[z].second-1);
                return ans;
            }
        }*/
    }

    return ans;
}
