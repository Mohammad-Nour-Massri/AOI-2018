

#include "teams.h"
#include <bits/stdc++.h>
using namespace std;
const int inf = 5e5+9;
int n,team[inf];
vector<int> v[inf];

void init(int N, int A[], int B[]) {
    n = N;
    for(int i=0;i<n;i++)
        v[ A[i] ] .push_back( B[i] );
}

int can(int M, int K[]) {

    for(int i=1;i<=n;i++)
        team[i] = 0;

    multiset<int> CurEnd;
    for(int i=0;i<M;i++)
        team[ K[i] ] +=K[i] ;

    for(int i=1;i<=n;i++){
        while(!CurEnd.empty() && *CurEnd.begin()<i)
            CurEnd.erase(CurEnd.begin());

        for(auto o:v[i])
            CurEnd.insert(o);

        if(CurEnd.size() < team[i])
            return 0;
        while(team[i]--)
            CurEnd.erase(CurEnd.begin());

    }

    return 1;
}
