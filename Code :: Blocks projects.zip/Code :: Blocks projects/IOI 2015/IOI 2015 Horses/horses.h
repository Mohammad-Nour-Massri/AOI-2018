#ifndef horses_h
#define horses_h

int init(int N, int X[], int Y[]);
int updateX(int pos, int val);
int updateY(int pos, int val);

#endif
