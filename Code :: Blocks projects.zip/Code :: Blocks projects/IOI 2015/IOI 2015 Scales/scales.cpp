//55 points
#include "scales.h"
#include <bits/stdc++.h>
using namespace std;
int larger[8][8],tmp[] = {1,2,3},tmp2[] = {4,5,6},done[44];

void init(int T) {
    memset(larger,-1,sizeof(larger));
    memset(done,0,sizeof(done));
}

void modify(int x,int y){//x<y

    larger[x][y] = 0;
    larger[y][x] = 1;
}

void modify(int a,int b,int c){//a<b<c

    larger[c][b] = larger[c][a] = 1;
    larger[b][c] = larger[a][c] = 0;
    larger[b][a] = 1 , larger[a][b] = 0;
}

void ask(int x,int y,int z){

    int a,b,c;
    a = getLightest(x,y,z);
    c = getHeaviest(x,y,z);
    if( (a == x && c == z) || (c == x && a == z))
        b = y;
    else if( (a == y && c == z) || (a == z && c == y) )
        b = x;
    else
         b = z;
    modify(a,b,c);
}

bool cmp(int x,int y){

    return larger[y][x];
}

void loop(int cur){

    int x = getNextLightest(tmp[0],tmp[1],tmp[2],cur) , i;
    for(i=0;i<3;i++){
        if(tmp[i] == x)
            break;
        modify(tmp[i],cur);
    }
    for(;i<3;i++)
        modify(cur,tmp[i]);
}

void orderCoins() {

    int W [] = {1,2,3,4,5,6};
    ask(1,2,3);
    ask(4,5,6);
    sort(tmp,tmp+3,cmp);
    sort(tmp2,tmp2+3,cmp);

    int md= getMedian(tmp[2],tmp[1],tmp2[2]);
    //cout<<md<<endl;
    bool is;//is == 1 if tmp[2] > tmp2[2]
    //if tmp[2] > tmp2[2] then there will be always an element from tmp larger than from any element from tmp2
    //if tmp[2] < tmp2[2] so swap tmp,tmp2 and that condition will be satisied
    is = (md == tmp[1] || md == tmp2[2]);

    if(!is){
        for(int i=0;i<3;i++)
            swap(tmp[i],tmp2[i]);
    }
    for(int i=0;i<3;i++)
        loop(tmp2[i]);

    sort(W,W+6,cmp);
    answer(W);
}
