
// 100 points
#include "boxes.h"
#include <bits/stdc++.h>
#define ll long long
using namespace std;
const ll inf = 1e7+9,MX = 1e18+9;

ll predir1[inf],predir2[inf],add[inf];

ll delivery(int n, int k, int l, int p[]) {

    ll ret = MX;
    sort(p,p+n);

    for(int i=0;i<n;i++){
        add[i%k] += p[i] + min(l-p[i],p[i]);
        predir1[i] = add[i%k];
    }

    for(int i=0;i<k;i++)
        add[i] = 0;
    ll cnt=0;
    for(int i=n-1;i>=0;i--){
        add[cnt%k] += (l-p[i]) + min(l-p[i],p[i]);
        predir2[i] += add[cnt%k];
        cnt++;
    }

    for(int i=-1;i<n;i++){
        ll tmp=0;
        if( i != -1)
            tmp+=predir1[i];
        if(i != n-1)
            tmp+=predir2[i+1];
        ret = min(ret , tmp);
    }
    return ret;
}

/*
    // 50 points
    #include "boxes.h"
    #include <bits/stdc++.h>
    #define ll long long
    using namespace std;
    const ll MX = 1e18+9;

    ll delivery(int n, int k, int l, int p[]) {

        ll ret = MX;
        sort(p,p+n);

        for(int i=-1;i<n;i++){
            ll tmp=0,cnt=0;
            vector<ll> dir1,dir2;

            for(int j=0;j<=i;j++)
                dir1.push_back(p[j]);

            for(int j=n-1;j>i;j--)
                dir2.push_back(l-p[j]);

            sort(dir1.begin(),dir1.end());
            sort(dir2.begin(),dir2.end());

            for(int j=dir1.size()-1;j>=0;j--){
                if(cnt == 0)
                    tmp+=dir1[j]+min(dir1[j],l-dir1[j]);
                cnt++;
                cnt %= k;
            }
            cnt = 0;
            for(int j=dir2.size()-1;j>=0;j--){
                if(cnt == 0)
                    tmp+= dir2[j]+min(dir2[j],l-dir2[j]);
                cnt++;
                cnt %= k;
            }
            ret = min(ret , tmp);
        }
        return ret;
    }
    */
