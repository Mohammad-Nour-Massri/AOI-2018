
#include "railroad.h"
#include <bits/stdc++.h>
#define ll long long
using namespace std;
const int inf = 2e5+9 , MX = 1e18+9;

bool operator <(pair<int,int> x,pair<int,int> y){
    if(x.first == y.first)
        return x.second>y.second;
    return x.first<y.first;
}

int n;
multiset<pair<int,int> > s;

long long plan_roller_coaster(vector<int> S, vector<int> T) {

    n = (int) S.size();
    for(int i=0;i<n;i++)
        s.insert(make_pair(S[i],T[i]));

    int curt = 1;
    while(!s.empty()){
        multiset<pair<int,int> > ::iterator it = s.lower_bound(make_pair(curt,-1));
        if(it == s.end())
            return 1;

        curt = it->second;
        s.erase(it);
    }
    return 0;
}
/*
//34 points
#include "railroad.h"
#include <bits/stdc++.h>
#define ll long long
using namespace std;
const ll inf = 17 , MX = 1e18+9;
ll n,s[inf],t[inf],dp[(1<<inf)][inf];

ll solve(ll mask,ll cur){

    if(mask == (1ll<<n)-1ll)
        return 0;
    ll &ret = dp[mask][cur];
    if(ret != -1)
        return ret;
    ret = MX;
    for(int i=0;i<n;i++)
        if(!(mask & (1ll<<i) ) )
            ret = min(ret , solve( mask | (1ll<<i) , i ) + max( 0ll , t[cur] - s[i] ) );

    return ret;
}

long long plan_roller_coaster(vector<int> S, vector<int> T) {
    ll ans = MX;
    n = (ll) S.size();
    for(ll i=0;i<n;i++)
        s[i] = S[i],t[i] = T[i];

    memset(dp,-1,sizeof(dp));

    for(int i=0;i<n;i++)
        ans = min( ans , solve((1<<i),i) );
    return ans;
}
*/
